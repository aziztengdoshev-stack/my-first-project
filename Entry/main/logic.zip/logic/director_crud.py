from .db_helper import query_db

class DirectorCRUD:
    # --- УЧИТЕЛЯ ---
    
    # Получаем список всех работающих учителей
    def get_all_teachers(self):
        return query_db("SELECT id, username, fio, subject FROM teachers")

    # Директор сам создает учителя, он сразу активен
    def add_teacher(self, username, password, fio, subject):
        check = query_db("SELECT id FROM teachers WHERE username=?", (username,), fetchone=True)
        if not check:
            query_db(
                "INSERT INTO teachers (username, password, fio, subject) VALUES (?, ?, ?, ?)", 
                (username, password, fio, subject)
            )
            return True
        return False

    # Удаление учителя (увольнение)
    def delete_teacher(self, teacher_id):
        query_db("DELETE FROM teachers WHERE id=?", (teacher_id,))

    # --- КЛАССЫ ---

    # Список всех классов школы
    def get_all_classes(self):
        return query_db("SELECT * FROM classes")

    # Добавление нового класса (например, 9-"А")
    def add_class(self, class_name):
        check = query_db("SELECT id FROM classes WHERE name=?", (class_name,), fetchone=True)
        if not check:
            query_db("INSERT INTO classes (name) VALUES (?)", (class_name,))
            return True
        return False

    # Удаление класса
    def delete_class(self, class_id):
        query_db("DELETE FROM classes WHERE id=?", (class_id,))