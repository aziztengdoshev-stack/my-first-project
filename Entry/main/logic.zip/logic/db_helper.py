import sqlite3
import os

# Путь к твоей базе данных
DB_PATH = os.path.join(os.path.dirname(__file__), '../../school.db')

def query_db(sql, params=(), fetchone=False):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row # Это позволит обращаться к колонкам по именам: row['name']
        cursor = conn.cursor()
        cursor.execute(sql, params)
        conn.commit()
        if fetchone:
            res = cursor.fetchone()
            return dict(res) if res else None
        return [dict(r) for r in cursor.fetchall()]